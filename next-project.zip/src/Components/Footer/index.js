import React from "react";

export default function Footer() {
  return (
    <>
      <footer className="bg-dark text-white mt-5 p-4 text-center">
      <div className="container">
        <div className="row">
          <div className="col-md-4">
            <h5>About Us</h5>
            <p className="text-muted">
              We are a company dedicated to providing the best services in the
              industry. Our team is committed to excellence and innovation.
            </p>
          </div>
          <div className="col-md-4">
            <h5>Contact</h5>
            <p className="text-muted">
              Email: info@ourcompany.com
              <br />
              Phone: (123) 456-7890
              <br />
              Address: 123 Main Street, Anytown, USA
            </p>
          </div>
          <div className="col-md-4">
            <h5>Follow Us</h5>
            <a href="#" className="text-white me-2">
              <i className="fab fa-facebook-f"></i>
            </a>
            <a href="#" className="text-white me-2">
              <i className="fab fa-twitter"></i>
            </a>
            <a href="#" className="text-white me-2">
              <i className="fab fa-instagram"></i>
            </a>
            <a href="#" className="text-white">
              <i className="fab fa-linkedin-in"></i>
            </a>
          </div>
        </div>
        <div className="row mt-3">
          <div className="col-md-12">
            <p className="text-muted">
              &copy; {new Date().getFullYear()} Our Company. All rights
              reserved. | Privacy Policy | Terms of Service
            </p>
          </div>
        </div>
      </div>
    </footer>
    </>
  );
}
