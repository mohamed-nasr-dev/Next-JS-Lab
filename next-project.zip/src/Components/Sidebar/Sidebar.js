import Link from "next/link";
import React from "react";

export default function Sidebar() {
  const links = [
    { title: "courses", href: "/user/courses" },
    { title: "Projects user", href: "/user/userProject" },
    { title: "Degree", href: "" },
  ];

  return (
    <div>
    <h2 className="text-dark my-2">page of Users</h2>
      <ul className="nav flex-column">
        {links.map((link,i) => (
          <li key={i} className="nav-item  text-bg-dark w-50 text-center my-2">
            <Link
              className="nav-link active text-warning border-0 rounded-5"
              href={link.href}
            >
              {link.title}
            </Link>
          </li>
        ))}
      </ul>
    </div>
  );
}
