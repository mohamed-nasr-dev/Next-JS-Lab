import userModel from "@/app/_lib/model/user";
import { GET } from "@/app/api/users/[id]/route";
import React from "react";




export async function generateMetadata({params}) {
  const user = await userModel.findById(params.id);
  return {
    title:user.userName
  }


  
}



const UserDetails = async ({ params }) => {

  const user = await userModel.findById(params.id);

  console.log(user);
  
  return (
    <>
      <div className="container mt-5">
        <div className="row">
          <div className="col-md-12">
            <h1 className="display-4 text-primary">User Details</h1>
            <p className="lead text-secondary">
              Here you can find the details of our users.
            </p>
            <hr className="my-4" />

            {/* ############ */}
            <div className="container">
              <div className="row">
                <div className="col-sm">
                  <img
                    src="https://plus.unsplash.com/premium_photo-1664536392896-cd1743f9c02c?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MXx8cGVyc29ufGVufDB8fDB8fHww"
                    className="w-50"
                  />
                </div>
                <div className="col-sm">
                  <h2 className="card-title my-5 text-bg-dark text-center">
                    {" "}
                    Name :{user.userName}
                  </h2>
                  <h5 className="my-3">
                    <strong>Email:</strong> {user.email}
                  </h5>

                  {/* <h5 className="my-3">
                    <strong>Phone:</strong> {user.phone}
                  </h5> */}
                 
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default UserDetails;
