import React from "react";

import "./courses.css";
export default function page() {
  const info = [
    {
      id: 1,
      courseImg:
        "https://c4.wallpaperflare.com/wallpaper/788/440/942/reactjs-react-native-tech-developer-development-hd-wallpaper-preview.jpg",
      degree: "good",
      courseTitle: "React js   ",
    },
    {
      id: 2,
      courseImg:
        "https://imgs.search.brave.com/sjX-tg95vVnLN2MLfEeo36-XAdGj5b39NQdiLoNU12E/rs:fit:500:0:0:0/g:ce/aHR0cHM6Ly9pbWFn/ZXMuY3RmYXNzZXRz/Lm5ldC85M2U4c2xh/a3plYmYvVVhDU3Vh/dlVqRDRHS2JKcmFH/dnp6LzJkNjI1ODgy/ZmQ5MzIxMDZiZTc0/ZjAxZjc5ZGMzNjlm/L1Z1ZS5qcy1GcmFt/ZXdvcmtzLnBuZz9m/bT13ZWJwJnc9MTky/MCZxPTc1",
      degree: "pass",
      courseTitle: "Vue js   ",
    },
    {
      id: 3,
      courseImg:
        "https://imgs.search.brave.com/iQRxoaK5q74mncW1Sr1upF8KnydHJJht3ZOM_yh9vts/rs:fit:500:0:0:0/g:ce/aHR0cHM6Ly93d3cu/bGFtYmRhdGVzdC5j/b20vYmxvZy93cC1j/b250ZW50L3VwbG9h/ZHMvMjAyMy8wMi91/bm5hbWVkMjUyNTI1/MjUyNTIwLTI1MjUy/NTI1MjUyMDIwMjMt/MDItMTRUMTYwMTA2/LjMwMS5wbmc",
      degree: "V . good",
      courseTitle: "Node js   ",
    },
    {
      id: 4,
      courseImg:
        "https://imgs.search.brave.com/wqU5i0YewFffqERhyCf-sISmBelj5WLABXdD87mD5t8/rs:fit:500:0:0:0/g:ce/aHR0cHM6Ly9ibG9n/LmxvZ3JvY2tldC5j/b20vd3AtY29udGVu/dC91cGxvYWRzLzIw/MjEvMDkvbmV4dC1q/cy1hdXRvbWF0aWMt/aW1hZ2Utb3B0aW1p/emF0aW9uLW5leHQt/aW1hZ2UucG5n",
      degree: "good",
      courseTitle: "Next Js",
    },
    {
      id: 5,
      courseImg:
        "https://imgs.search.brave.com/rMAX5ZkF3lbKi5wzfews88IbebeJoZUOD2UxqH6Z-eE/rs:fit:500:0:0:0/g:ce/aHR0cHM6Ly9kMnNv/ZnZhd2UwOHlxZy5j/bG91ZGZyb250Lm5l/dC9ib29rLWFuZ3Vs/YXIvc19oZXJvPzE3/MDY2OTg3NjA.jpeg",
      degree: "Bad",
      courseTitle: " Angular ",
    },
  ];

  return (
    <>
      <div className="course-container">
        {info.map((user, i) => (
          <div key={i} className="my-4">
            <div className="book">
              <p>Course Name : {user.courseTitle}</p>
              <p>degree : {user.degree}</p>

              <div className="cover">
                <img src={user.courseImg} />
              </div>
            </div>
          </div>
        ))}
      </div>
    </>
  );
}
