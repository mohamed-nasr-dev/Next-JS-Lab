import React from 'react'
import "../courses/courses.css"
export default function page() {
  const info = [
    {
      id: 1,
      courseImg:"https://imgs.search.brave.com/0xag_ftrTu8ANffkPudb1u9T4zO4kevrG0f-8p2zo9A/rs:fit:500:0:0:0/g:ce/aHR0cHM6Ly9zMy11/cy13ZXN0LTIuYW1h/em9uYXdzLmNvbS9h/bmd1bGFyLXRlbXBs/YXRlcy9hbmd1bGFy/LWR1by10ZW1wbGF0/ZS9zY3JlZW5zaG90/cy9kdW8tdGVtcGxh/dGUtcmlnaHQtc2lk/ZS1tZW51LnBuZw",
      status: "good",
      ProjectName: "React js  Project   ",
    },
    {
      id: 2,
      courseImg:"https://imgs.search.brave.com/jTMDDUD1M029uUpBFmJnvlmMmP6R-tVXL802Ll_D2pg/rs:fit:500:0:0:0/g:ce/aHR0cHM6Ly90aGVt/ZXNlbGVjdGlvbi1j/ZG4uYi1jZG4ubmV0/L3dwLWNvbnRlbnQv/dXBsb2Fkcy8yMDIy/LzA1L0thcC1mcmVl/LWltYWdlLnBuZw",
      status: "pass",
      ProjectName: "Vue js Project ",
    },
    {
      id: 3,
      courseImg:"https://imgs.search.brave.com/fHvZWI-uDZpUTB68U7BiIOh_1LN-l2RzKPgDy0avZUA/rs:fit:500:0:0:0/g:ce/aHR0cHM6Ly9maWxl/cy5zbWFzaGluZy5t/ZWRpYS9wYXJ0bmVy/cy9zbWFzaGluZy9i/cmFkLWZyb3N0LWFk/dmFuY2VkLnBuZw"
       ,
      status: "V . good",
      ProjectName: "Node js Project",  
    },
    {
      id: 4,
      courseImg:"https://imgs.search.brave.com/m006Qk_WMjV1IB7Qj0HH7g_3lbP8GdJ_giF5sTk17gI/rs:fit:500:0:0:0/g:ce/aHR0cHM6Ly9maWxl/cy5zbWFzaGluZy5t/ZWRpYS9wYXJ0bmVy/cy9zbWFzaGluZy9v/bGl2ZXItc2Nob25k/b3JmZXIucG5n",
      status: "good",
      ProjectName: " java Script Project",
    },
    {
      id: 5,
      courseImg:"https://imgs.search.brave.com/22csh41Wmomt_uZZGeGAC7QZup0S52yMTQCtzPF3_vQ/rs:fit:500:0:0:0/g:ce/aHR0cHM6Ly9yZXMu/Y2xvdWRpbmFyeS5j/b20vcHJhY3RpY2Fs/ZGV2L2ltYWdlL2Zl/dGNoL3MtLXpGZUo1/alZVLS0vY19saW1p/dCxmX2F1dG8sZmxf/cHJvZ3Jlc3NpdmUs/cV9hdXRvLHdfODgw/L2h0dHBzOi8vcmVz/LmNsb3VkaW5hcnku/Y29tL2Rxc2UydHh5/aS9pbWFnZS91cGxv/YWQvdjE2NDkxOTA4/MjMvYmxvZ3MvbmV4/dGpzLWZ1bGxzdGFj/ay1hcHAtdGVtcGxh/dGUvbmV4dC1sYXlv/dXQtMDFfaWphZG94/LnBuZw",
      status: "Bad",
      ProjectName: " Angula  Projectr ",
    },
  ];

  return (
    <>
   <div className="course-container">
   {info.map((project, i) => (
        <div key={i} className="my-4">
          <div className="book">
          
            <p>Course Name : {project.ProjectName}</p>
            <p>status : {project.status}</p>
           
            <div className="cover">
              <img src={project.courseImg} />
            </div>
          </div>
        </div>
      ))}
   </div>
    </>
  );
}
