import NextAuth from "next-auth"
import Google from "next-auth/providers/google"

export const { handlers:{GET,POST}, auth, signIn, signOut } = NextAuth({
  providers: [Google({
    clientId:process.env.AUTH_GOOGLE_ID,
    clientSecret:process.env.AUTH_GOOGLE_SECRET
  })],
})
 
// import NextAuth from "next-auth";
// import GoogleProvider from "next-auth/providers/google";

// export default NextAuth({
//   // Configure one or more authentication providers
//   providers: [
//     GoogleProvider({
//       clientId: process.env.GOOGLE_CLIENT_ID,
//       clientSecret: process.env.GOOGLE_CLIENT_SECRET,
//     }),
//   ],
//   // Optional: configure callbacks, pages, etc.
//   callbacks: {
//     async session({ session, token, user }) {
//       session.user.id = token.sub;
//       return session;
//     },
//   },
// });
