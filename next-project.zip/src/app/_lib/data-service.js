export const getAllUser=()=>{

}