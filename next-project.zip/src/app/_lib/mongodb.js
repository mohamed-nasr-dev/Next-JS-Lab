import mongoose from "mongoose";

export function dbConnection() {
  mongoose
    .connect("mongodb://localhost:27017/next-todo")
    .then(() => {
      console.log("successful db connection");
    })
    .catch((err) => {
      console.log(err);
    });
}
