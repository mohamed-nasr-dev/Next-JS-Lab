"use server";

import { revalidatePath } from "next/cache";
import userModel from "./model/user";
import { redirect } from "next/navigation";

export async function addNewUser(FormData) {
  // console.log(...FormData);
  let userName = FormData.get("userName");
  let email = FormData.get("email");
  let password = FormData.get("password");

  const addUser = await userModel.create({ userName, email, password });

  revalidatePath("user");
  redirect("user");
}
// PUT function to update an existing user
export async function updateUser(userId, FormData) {
console.log("hamdaadd  ============>");
;
  let userName = FormData.get("userName");
  let email = FormData.get("email");
  let password = FormData.get("password");

  const updatedUser = await userModel.findByIdAndUpdate(
    userId,
    { userName, email, password },
    { new: true }
  );

  revalidatePath("user");
  redirect("user");
}

// PATCH function to update specific fields of an existing user
export async function patchUser(userId, FormData) {
 
  let updateData = {};
  if (FormData.has("userName")) updateData.userName = FormData.get("userName");
  if (FormData.has("email")) updateData.email = FormData.get("email");
  if (FormData.has("password")) updateData.password = FormData.get("password");

  const patchedUser = await userModel.findByIdAndUpdate(userId, updateData, {
    new: true,
  });

  revalidatePath("user");
  redirect("user");
}

// DELETE function to remove an existing user
export async function deleteUser(userId) {
  // console.log(userId);
  console.log('ham+>>>>>>>>>>');
  try{
    const deletedUser = await userModel.findByIdAndDelete(userId);
    if (!deletedUser) {
      return "your User is not Founded "
      
      
    }
    revalidatePath("user");
    redirect("user");

  }catch(err){
    console.log(err);
    

  }

}
