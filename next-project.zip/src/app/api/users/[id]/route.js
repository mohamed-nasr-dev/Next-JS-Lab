import userModel from "@/app/_lib/model/user";



export async function GET(_ ,{params}){


// console.log("user by id+>>>>>>>>>>>>>>>>>>>");

    const user = await userModel.findById(params.id);
    try{
        if (user) {
            return new Response(JSON.stringify(user),{status:200})

        }
    }catch(err){
        return new Response(JSON.stringify({message:`Not Found this User `}),{status:400})

    }



}



