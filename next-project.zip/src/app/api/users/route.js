import userModel from "@/app/_lib/model/user";
import { ZodSchema } from "zod";
import { zodSchema } from "./zodSchema";

const { dbConnection } = require("@/app/_lib/mongodb");

//call function
dbConnection();

export async function GET() {
  try {
    const users = await userModel.find();
    return new Response(JSON.stringify(users), { status: 200 });
  } catch (err) {
    console.error(err);
    return new Response(
      JSON.stringify({
        message: "same thing is happened => please  try again anther time ",
      }),
      { status: 400 }
    );
  }
}

export async function POST(request) {
  const user = await request.json();
  try {
    const validation = zodSchema.safeParse(user);
    console.log(validation.error);
    
    if (!validation.success) {
      return new Response(
        JSON.stringify({
          message: `invalid input this user ${validation.error.errors}`,
        }),
        { status: 400 }
      );
    }
    const createNewUser = await userModel.create(user);
    return new Response(
      JSON.stringify(createNewUser),
      { status: 201 }
    );
  } catch (err) {
    return new Response(
      JSON.stringify({ message: `user created Filed ${err.message}` }),
      { status: 400 }
    );
  }
}
// ###################

export async function PUT(request) {
  const user = await request.json();
  try {
    const validation = zodSchema.safeParse(user);
    if (!validation.success) {
      return new Response(
        JSON.stringify({
          message: `Invalid input: ${validation.error.errors}`,
        }),
        { status: 400 }
      );
    }
    const updatedUser = await userModel.findByIdAndUpdate(user._id, user, { new: true });
    if (!updatedUser) {
      return new Response(
        JSON.stringify({ message: "User not found" }),
        { status: 404 }
      );
    }
    return new Response(JSON.stringify(updatedUser), { status: 200 });
  } catch (err) {
    return new Response(
      JSON.stringify({ message: `User update failed: ${err.message}` }),
      { status: 400 }
    );
  }
}

export async function PATCH(request) {
  const user = await request.json();
  try {
    const validation = zodSchema.partial().safeParse(user);
    if (!validation.success) {
      return new Response(
        JSON.stringify({
          message: `Invalid input: ${validation.error.errors}`,
        }),
        { status: 400 }
      );
    }
    const updatedUser = await userModel.findByIdAndUpdate(user._id, user, { new: true });
    if (!updatedUser) {
      return new Response(
        JSON.stringify({ message: "User not found" }),
        { status: 404 }
      );
    }
    return new Response(JSON.stringify(updatedUser), { status: 200 });
  } catch (err) {
    return new Response(
      JSON.stringify({ message: `User update failed: ${err.message}` }),
      { status: 400 }
    );
  }
}

export async function DELETE(request,{params}) {
  console.log(request);
  

  const { id } = await request.json();
  try {
    const deletedUser = await userModel.findByIdAndDelete(id);
    if (!deletedUser) {
      return new Response(
        JSON.stringify({ message: "User not found" }),
        { status: 404 }
      );
    }
    return new Response(JSON.stringify({ message: "User deleted successfully" }), { status: 200 });
  } catch (err) {
    return new Response(
      JSON.stringify({ message: `User deletion failed: ${err.message}` }),
      { status: 400 }
    );
  }
}