const { z } = require("zod");

export const zodSchema= z.object({
    userName: z.string().min(2).max(100),
    email: z.string().email(),
    password: z.string().min(4).max(30),

})