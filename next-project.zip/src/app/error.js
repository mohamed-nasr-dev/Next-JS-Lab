"use client"

import React from "react";

export default function error() {
  return (
    <>
     <div className="container text-center mt-5">
      <div className="alert alert-danger" role="alert">
        An error has occurred. Please try again later.
      </div>
    </div>
    </>
  );
}
