import React from "react";
import { Form } from "react-bootstrap";
import "./login.css";
import { addNewUser } from "../_lib/server-action";

// import userModel from "../_lib/model/user";
// import { redirect } from "next/navigation";
// import { revalidatePath } from "next/cache";

// async function AddNewUser(FormData) {
//   "use server";
//   console.log(...FormData);
//   let userName = FormData.get("userName");
//   let email = FormData.get("email");
//   let password = FormData.get("password");

//   const addUser = await userModel.create({ userName, email, password });

//   revalidatePath("user");
//   redirect("user");
// }

export default function Login() {
  return (
    <>
      <div className="container mt-5 ">
        <div className="row justify-content-center h1 m-4 text-bg-dark p-3 border rounded-5">
          User Login
        </div>
        <form className="form" action={addNewUser}>
          <input
            placeholder="Enter your name"
            className="input"
            type="text"
            name="userName"
          />
          <input
            placeholder="Enter your email"
            className="input"
            type="text"
            name="email"
          />
          <input
            placeholder="Enter your Password   ***"
            className="input"
            type="password"
            name="password"
          />

          <button>Submit</button>
          
        </form>

      </div>
    </>
  );
}
