import React from 'react'

export default function NotFound() {
  return (
    <>
       <div className="container text-center mt-5">
      <div className="alert alert-warning" role="alert">
        404 - Page Not Found
      </div>
    </div>
    bs5-
    </>
  )
}
