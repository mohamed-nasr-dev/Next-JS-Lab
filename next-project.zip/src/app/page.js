import Image from "next/image";
import styles from "./page.module.css";
import Navbar from "@/Components/Header";

export default function Home() {
  return (
    <>
    <Navbar/>
      <div className="container mt-5">
        <div className="row">
          <div className="col-md-6">
            <Image
              src="/path/to/your/image.jpg"
              alt="Descriptive Alt Text"
              width={500}
              height={300}
              className="img-fluid rounded"
            />
          </div>
          <div className="col-md-6">
            <h1 className="display-4 text-primary">Welcome to Our Website</h1>
            <p className="lead text-secondary">
              This is a simple hero unit, a simple jumbotron-style component for
              calling extra attention to featured content or information.
            </p>
            <hr className="my-4" />
            <p className="text-muted">
              It uses utility classes for typography and spacing to space
              content out within the larger container.
            </p>
            <a className="btn btn-primary btn-lg" href="#" role="button">
              Learn more
            </a>
          </div>
        </div>
      </div>
    </>
  );
}
